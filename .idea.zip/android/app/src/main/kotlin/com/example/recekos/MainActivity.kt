package com.example.recekos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
